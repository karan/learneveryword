twitter = dict(
  key = 'KbBFmmJ2V2zPpkmXg81PPmqET',
  secret = 'ot4V9Y6NC7jDQXrpxqIK063dX9OI9x9S0OzcT1zpqsqL4QAQ52',
  token = '4842001652-LAUaSJE6L0y8cmxxNggqdPAQhhVibiKPuwYgMmC',
  token_secret = '6EAlD09sOIUKSAuGX4QITnkAjEoCfB9ZBOfv8JbHHQgm4',
)

aws = dict(
  key = 'AKIAJT5LCMOO5EKOZ3NQ',
  secret = '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',
  bucket = 'learneveryword',
  data = 'data.json',
)
